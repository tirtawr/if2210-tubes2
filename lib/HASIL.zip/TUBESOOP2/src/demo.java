public interface demo {
	public void runGUI();
	public void runConsole();
}
