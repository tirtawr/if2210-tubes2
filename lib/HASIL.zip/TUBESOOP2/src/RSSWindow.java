



/*public class RSSWindow {

	
	public static void main(String[] args) {
		SLAnimator.start();

		TheFrame frame = new TheFrame();
		frame.topTen();
		frame.setSize(1024, 700);
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
	}
}*/
