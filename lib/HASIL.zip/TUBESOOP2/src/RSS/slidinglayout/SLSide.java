package RSS.slidinglayout;

public enum SLSide {
	TOP, BOTTOM, LEFT, RIGHT
}
